/* This is just a sandbox for debugging miniaudio. Do not run this as part of some automated testing process. */
#include "../../miniaudio.c"

int main(int argc, char** argv)
{
    (void)argc;
    (void)argv;

    return 0;
}
