#version 330 core
out vec4 FragColor;
in vec2 TexCoords;

uniform sampler2D screenTexture;

// ---- Advanced Color Controls ----
uniform float brightness;    // default: 0.0  (range: -1.0 → +1.0)
uniform float contrast;      // default: 1.0  (range: 0.0 → 2.0)
uniform float saturation;    // default: 1.0  (range: 0.0 → 2.0)
uniform float hue;           // default: 0.0  (radians: -3.14 → +3.14)
uniform float gamma;         // default: 1.0  (range: 0.5 → 2.5)
uniform float exposure;      // default: 1.0  (range: 0.5 → 2.0)
uniform float temperature;   // default: 0.0  (range: -1.0 → +1.0, warm/cool)

vec3 adjustHue(vec3 color, float angle)
{
    float cosA = cos(angle);
    float sinA = sin(angle);
    mat3 hueRot = mat3(
        0.299 + 0.701 * cosA + 0.168 * sinA, 0.587 - 0.587 * cosA + 0.330 * sinA, 0.114 - 0.114 * cosA - 0.497 * sinA,
        0.299 - 0.299 * cosA - 0.328 * sinA, 0.587 + 0.413 * cosA + 0.035 * sinA, 0.114 - 0.114 * cosA + 0.292 * sinA,
        0.299 - 0.300 * cosA + 1.250 * sinA, 0.587 - 0.588 * cosA - 1.050 * sinA, 0.114 + 0.886 * cosA - 0.203 * sinA
    );
    return clamp(hueRot * color, 0.0, 1.0);
}

vec3 adjustSaturation(vec3 color, float sat)
{
    float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
    return mix(vec3(luma), color, sat);
}

vec3 adjustContrast(vec3 color, float cont)
{
    return (color - 0.5) * cont + 0.5;
}

vec3 adjustTemperature(vec3 color, float temp)
{
    vec3 warm = vec3(1.1, 1.0, 0.9);
    vec3 cool = vec3(0.9, 1.0, 1.1);
    return mix(color * cool, color * warm, temp * 0.5 + 0.5);
}

void main()
{
    vec3 color = texture(screenTexture, TexCoords).rgb;

    // --- Exposure ---
    color *= exposure;

    // --- Brightness & Contrast ---
    color = adjustContrast(color + brightness, contrast);

    // --- Saturation & Hue ---
    color = adjustSaturation(color, saturation);
    color = adjustHue(color, hue);

    // --- Color Temperature ---
    color = adjustTemperature(color, temperature);

    // --- Gamma correction ---
    color = pow(color, vec3(1.0 / gamma));

    FragColor = vec4(color, 1.0);
}
