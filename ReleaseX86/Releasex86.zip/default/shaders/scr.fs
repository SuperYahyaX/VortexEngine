#version 330 core
out vec4 FragColor;
in vec2 TexCoords;
uniform sampler2D screenTexture;
uniform float bloomThreshold;

void main()
{
    vec3 hdrColor = texture(screenTexture, TexCoords).rgb;
    
    // Extract bright parts for bloom
    float brightness = dot(hdrColor, vec3(0.2126, 0.7152, 0.0722));
    if(brightness > bloomThreshold) {
        FragColor = vec4(hdrColor, 1.0);
    } else {
        FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    }
}