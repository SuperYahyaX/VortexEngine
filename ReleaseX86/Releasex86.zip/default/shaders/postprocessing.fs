#version 330 core
out vec4 FragColor;

in vec2 TexCoords;

uniform sampler2D screenTexture;
uniform sampler2D bloomBlur;
uniform bool chromaticAberrationEnabled;
uniform bool bloomEnabled;
uniform float chromaticStrength;
uniform float bloomIntensity;
uniform float bloomThreshold;

// Chromatic aberration function
vec3 chromaticAberration(sampler2D tex, vec2 uv, float strength) {
    if (!chromaticAberrationEnabled) {
        return texture(tex, uv).rgb;
    }
    
    vec2 direction = normalize(uv - vec2(0.5));
    float dist = length(uv - vec2(0.5));
    
    float red = texture(tex, uv - direction * strength * dist).r;
    float green = texture(tex, uv).g;
    float blue = texture(tex, uv + direction * strength * dist).b;
    
    return vec3(red, green, blue);
}

// Extract bright parts for bloom
vec3 extractBrightParts(vec3 color, float threshold) {
    float brightness = dot(color, vec3(0.2126, 0.7152, 0.0722));
    return color * max(brightness - threshold, 0.0);
}

void main()
{
    // Base color with chromatic aberration
    vec3 baseColor = chromaticAberration(screenTexture, TexCoords, chromaticStrength);
    
    // Bloom effect
    if (bloomEnabled) {
        // Extract bright parts from original texture
        vec3 hdrColor = texture(screenTexture, TexCoords).rgb;
        vec3 bloomColor = extractBrightParts(hdrColor, bloomThreshold);
        
        // Add blurred bloom
        vec3 blurredBloom = texture(bloomBlur, TexCoords).rgb;
        baseColor += blurredBloom * bloomIntensity;
    }
    
    // Tone mapping and gamma correction
    vec3 result = vec3(1.0) - exp(-baseColor * 1.0); // Simple tone mapping
    result = pow(result, vec3(1.0/2.2)); // Gamma correction
    
    FragColor = vec4(result, 1.0);
}