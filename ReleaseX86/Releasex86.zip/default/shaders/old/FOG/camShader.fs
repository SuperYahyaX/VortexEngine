#version 330 core
out vec4 FragColor;

in vec3 FragPos;
in vec2 TexCoord;
in vec3 TangentLightPos;
in vec3 TangentViewPos;
in vec3 TangentFragPos;
in float FogDistance;

// Material properties
struct Material {
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    float shininess;
};

// Light properties
struct Light {
    bool enabled;
    int type;
    vec3 position;
    vec3 direction;
    vec3 color;
    float intensity;
    float ambient;
    float diffuse;
    float specular;
    
    // Point light properties
    float constant;
    float linear;
    float quadratic;
    
    // Spot light properties
    float cutOff;
    float outerCutOff;
};

// Fog types - MUST DEFINE THESE
#define FOG_LINEAR 0
#define FOG_EXP 1
#define FOG_EXP2 2
#define FOG_VOLUMETRIC 3

// Fog uniforms
uniform bool fogEnabled;
uniform int fogType;
uniform vec3 fogColor;
uniform float fogDensity;
uniform float fogStart;
uniform float fogEnd;
uniform float fogOpacity;

// Volumetric fog uniforms
uniform bool volumetricFogEnabled;
uniform int volumetricFogSteps;
uniform float volumetricFogScattering;
uniform float volumetricFogAbsorption;
uniform float volumetricFogPhase;
uniform float volumetricFogNoiseScale;
uniform float volumetricFogNoiseStrength;
uniform vec3 volumetricFogWind;
uniform bool volumetricFogAnimate;
uniform sampler3D volumetricNoiseTexture;

uniform vec3 viewPos;
uniform Material material;
uniform Light lights[64];
uniform int numLights;
uniform bool lightingEnabled;
uniform bool useBlinnPhong;
uniform bool normalMappingEnabled;
uniform vec3 ambientLightColor;
uniform float ambientLightIntensity;
uniform sampler2D texture1;
uniform sampler2D normalMap;

uniform float time; // For animation

// Noise functions for volumetric fog
float hash(vec3 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float noise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    
    return mix(mix(mix(hash(i + vec3(0,0,0)), 
                     hash(i + vec3(1,0,0)), f.x),
               mix(hash(i + vec3(0,1,0)), 
                     hash(i + vec3(1,1,0)), f.x), f.y),
           mix(mix(hash(i + vec3(0,0,1)), 
                     hash(i + vec3(1,0,1)), f.x),
               mix(hash(i + vec3(0,1,1)), 
                     hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}

// Henyey-Greenstein phase function
float phaseFunction(float cosTheta, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * 3.14159 * pow(1.0 + g2 - 2.0 * g * cosTheta, 1.5));
}

// Sample volumetric fog density
float sampleFogDensity(vec3 worldPos) {
    if (!volumetricFogEnabled) return 0.0;
    
    vec3 samplePos = worldPos * volumetricFogNoiseScale;
    
    if (volumetricFogAnimate) {
        samplePos += volumetricFogWind * time;
    }
    
    // Use texture noise
    float noiseVal = texture(volumetricNoiseTexture, samplePos).r;
    
    // Add some turbulence with procedural noise
    float turbulence = noise(samplePos * 2.0) * 0.5 + 
                      noise(samplePos * 4.0) * 0.25;
    
    return (noiseVal + turbulence * volumetricFogNoiseStrength) * fogDensity;
}

// Calculate volumetric fog using ray marching
vec4 calculateVolumetricFog(vec3 rayOrigin, vec3 rayDir, float maxDistance) {
    if (!volumetricFogEnabled || maxDistance <= 0.0) {
        return vec4(0.0);
    }
    
    int steps = volumetricFogSteps;
    float stepSize = maxDistance / float(steps);
    
    // Find first directional or point light for lighting
    vec3 lightDir = vec3(0.0, 1.0, 0.0); // Default to upward light
    bool lightFound = false;
    
    for (int i = 0; i < numLights && !lightFound; i++) {
        if (lights[i].enabled) {
            if (lights[i].type == 0) { // Directional light
                lightDir = normalize(-lights[i].direction);
                lightFound = true;
            } else if (lights[i].type == 1) { // Point light
                lightDir = normalize(lights[i].position - rayOrigin);
                lightFound = true;
            }
        }
    }
    
    vec3 accumulatedFog = vec3(0.0);
    float transmittance = 1.0;
    
    for (int i = 0; i < steps; i++) {
        float t = (float(i) + 0.5) * stepSize;
        vec3 samplePos = rayOrigin + rayDir * t;
        
        // Sample fog density at this position
        float density = sampleFogDensity(samplePos);
        
        if (density > 0.0) {
            // Calculate lighting at sample point
            float lightDotView = dot(lightDir, -rayDir);
            float phase = phaseFunction(lightDotView, volumetricFogPhase);
            
            // In-scattering contribution
            vec3 scattering = fogColor * volumetricFogScattering * density * phase;
            
            // Absorption
            float absorption = volumetricFogAbsorption * density * stepSize;
            
            // Accumulate in-scattering
            accumulatedFog += scattering * transmittance * stepSize;
            
            // Update transmittance
            transmittance *= exp(-absorption);
            
            // Early exit if transmittance is very low
            if (transmittance < 0.01) break;
        }
    }
    
    return vec4(accumulatedFog, 1.0 - transmittance);
}

// Regular fog calculation function
float calculateFog()
{
    float fogFactor = 0.0;
    
    if (fogType == FOG_LINEAR)
    {
        fogFactor = (fogEnd - FogDistance) / (fogEnd - fogStart);
        fogFactor = clamp(fogFactor, 0.0, 1.0);
    }
    else if (fogType == FOG_EXP)
    {
        fogFactor = exp(-fogDensity * FogDistance);
        fogFactor = clamp(fogFactor, 0.0, 1.0);
    }
    else if (fogType == FOG_EXP2)
    {
        fogFactor = exp(-pow(fogDensity * FogDistance, 2.0));
        fogFactor = clamp(fogFactor, 0.0, 1.0);
    }
    
    return fogFactor;
}

vec3 calculateLight(Light light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 materialDiffuse, vec3 materialSpecular)
{
    if (!light.enabled) return vec3(0.0);
    
    vec3 lightDir;
    float attenuation = 1.0;
    
    if (light.type == 0) { // Directional light
        lightDir = normalize(-light.direction);
    } else if (light.type == 1) { // Point light
        lightDir = normalize(light.position - fragPos);
        float distance = length(light.position - fragPos);
        attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
    } else { // Spot light
        lightDir = normalize(light.position - fragPos);
        float theta = dot(lightDir, normalize(-light.direction));
        float epsilon = light.cutOff - light.outerCutOff;
        float intensity = clamp((theta - light.outerCutOff) / epsilon, 0.0, 1.0);
        intensity = pow(intensity, 1.5);
        attenuation = intensity;
    }
    
    // Ambient
    vec3 ambient = light.ambient * materialDiffuse * light.color * light.intensity;
    
    // Diffuse
    float diff = max(dot(normal, lightDir), 0.0);
    float wrap = 0.2;
    diff = max((diff + wrap) / (1.0 + wrap), 0.0);
    vec3 diffuse = light.diffuse * diff * materialDiffuse * light.color * light.intensity;
    
    // Specular
    float spec = 0.0;
    if (useBlinnPhong) {
        vec3 halfwayDir = normalize(lightDir + viewDir);
        float NdotH = max(dot(normal, halfwayDir), 0.0);
        float normalization = (material.shininess + 8.0) / (8.0 * 3.14159);
        spec = pow(NdotH, material.shininess) * normalization;
    } else {
        vec3 reflectDir = reflect(-lightDir, normal);
        float RdotV = max(dot(viewDir, reflectDir), 0.0);
        float normalization = (material.shininess + 2.0) / (2.0 * 3.14159);
        spec = pow(RdotV, material.shininess) * normalization;
    }
    vec3 specular = light.specular * spec * materialSpecular * light.color * light.intensity;
    
    return (ambient + diffuse + specular) * attenuation;
}

void main()
{
    if (!lightingEnabled) {
        FragColor = texture(texture1, TexCoord);
        return;
    }
    
    vec3 norm;
    vec3 viewDir;
    vec3 fragPos;
    
    if (normalMappingEnabled) {
        norm = texture(normalMap, TexCoord).rgb;
        norm = normalize(norm * 2.0 - 1.0);
        viewDir = normalize(TangentViewPos - TangentFragPos);
        fragPos = TangentFragPos;
    } else {
        vec3 worldNormal = normalize(cross(dFdx(FragPos), dFdy(FragPos)));
        norm = normalize(worldNormal);
        viewDir = normalize(viewPos - FragPos);
        fragPos = FragPos;
    }
    
    float NdotV = max(dot(norm, viewDir), 0.0);
    float fresnel = pow(1.0 - NdotV, 2.0);
    vec3 ambientGlobal = ambientLightColor * ambientLightIntensity * material.ambient * (1.0 + fresnel * 0.3);
    
    vec3 result = ambientGlobal;
    for (int i = 0; i < numLights; i++) {
        if (!lights[i].enabled) continue;
        result += calculateLight(lights[i], norm, fragPos, viewDir, material.diffuse, material.specular);
    }
    
    vec4 texColor = texture(texture1, TexCoord);
    vec4 finalColor = vec4(result, 1.0) * texColor;
    
    // Apply regular fog
    if (fogEnabled && fogType != FOG_VOLUMETRIC) {
        float fogFactor = calculateFog();
        finalColor = mix(vec4(fogColor, fogOpacity), finalColor, fogFactor);
    }
    
    // Apply volumetric fog
    if (volumetricFogEnabled || fogType == FOG_VOLUMETRIC) {
        vec3 rayOrigin = viewPos;
        vec3 rayDir = normalize(FragPos - viewPos);
        float rayLength = min(FogDistance, fogEnd);
        
        vec4 volumetricFog = calculateVolumetricFog(rayOrigin, rayDir, rayLength);
        
        // Combine volumetric fog with scene
        finalColor.rgb = finalColor.rgb * volumetricFog.a + volumetricFog.rgb;
    }
    
    FragColor = finalColor;
}