#version 330 core
out vec4 FragColor;

in vec3 FragPos;
in vec2 TexCoord;
in vec3 TangentLightPos;
in vec3 TangentViewPos;
in vec3 TangentFragPos;

// Material properties
struct Material {
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    float shininess;
};

// Light properties
struct Light {
    bool enabled;
    int type;
    vec3 position;
    vec3 direction;
    vec3 color;
    float intensity;
    float ambient;
    float diffuse;
    float specular;
    
    // Point light properties
    float constant;
    float linear;
    float quadratic;
    
    // Spot light properties
    float cutOff;
    float outerCutOff;
};

uniform vec3 viewPos;
uniform Material material;
uniform Light lights[64];
uniform int numLights;
uniform bool lightingEnabled;
uniform bool useBlinnPhong;
uniform bool normalMappingEnabled;
uniform vec3 ambientLightColor;
uniform float ambientLightIntensity;
uniform sampler2D texture1;
uniform sampler2D normalMap;

vec3 calculateLight(Light light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 materialDiffuse, vec3 materialSpecular)
{
    if (!light.enabled) return vec3(0.0);
    
    vec3 lightDir;
    float attenuation = 1.0;
    
    if (light.type == 0) { // Directional light
        lightDir = normalize(-light.direction);
    } else if (light.type == 1) { // Point light
        lightDir = normalize(light.position - fragPos);
        float distance = length(light.position - fragPos);
        attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
    } else { // Spot light
    lightDir = normalize(light.position - fragPos);
    float theta = dot(lightDir, normalize(-light.direction));
    float epsilon = light.cutOff - light.outerCutOff;
    
    // Smooth spot light falloff
    float intensity = smoothstep(0.0, 1.0, (theta - light.outerCutOff) / epsilon);
    intensity = clamp(intensity, 0.0, 1.0);
    
    // Add smooth attenuation curve
    intensity = pow(intensity, 1.5);
    attenuation = intensity;
}
    
    // Ambient
    vec3 ambient = light.ambient * materialDiffuse * light.color * light.intensity;
    
    // Diffuse
    // Improved diffuse with soft falloff
float diff = max(dot(normal, lightDir), 0.0);
// Apply wrap lighting for softer shadows
float wrap = 0.2;
diff = max((diff + wrap) / (1.0 + wrap), 0.0);
// Optional: use half-lambert for more artistic control
// diff = diff * 0.5 + 0.5;
    vec3 diffuse = light.diffuse * diff * materialDiffuse * light.color * light.intensity;
    
    // Specular
    // Replace the specular calculation with energy conservation
float spec = 0.0;
if (useBlinnPhong) {
    vec3 halfwayDir = normalize(lightDir + viewDir);
    float NdotH = max(dot(normal, halfwayDir), 0.0);
    
    // Improved Blinn-Phong with energy conservation
    float normalization = (material.shininess + 8.0) / (8.0 * 3.14159);
    spec = pow(NdotH, material.shininess) * normalization;
} else {
    vec3 reflectDir = reflect(-lightDir, normal);
    float RdotV = max(dot(viewDir, reflectDir), 0.0);
    
    // Improved Phong with energy conservation
    float normalization = (material.shininess + 2.0) / (2.0 * 3.14159);
    spec = pow(RdotV, material.shininess) * normalization;
}
    vec3 specular = light.specular * spec * materialSpecular * light.color * light.intensity;
    
    return (ambient + diffuse + specular) * attenuation;
}

void main()
{
    if (!lightingEnabled) {
        FragColor = texture(texture1, TexCoord);
        return;
    }
    
    vec3 norm;
    vec3 viewDir;
    vec3 fragPos;
    
    if (normalMappingEnabled) {
        // Use normal from normal map in tangent space
        norm = texture(normalMap, TexCoord).rgb;
        norm = normalize(norm * 2.0 - 1.0);
        viewDir = normalize(TangentViewPos - TangentFragPos);
        fragPos = TangentFragPos;
    }  else {
    // Improved normal calculation with better derivatives
    vec3 worldNormal = normalize(cross(dFdx(FragPos), dFdy(FragPos)));
    
    // Apply simple smoothing
    norm = normalize(worldNormal);
    viewDir = normalize(viewPos - FragPos);
    fragPos = FragPos;
}
    
    // Rest of the lighting calculation remains the same...
    //vec3 ambientGlobal = ambientLightColor * ambientLightIntensity * material.ambient;
    float NdotV = max(dot(norm, viewDir), 0.0);
float fresnel = pow(1.0 - NdotV, 2.0);
vec3 ambientGlobal = ambientLightColor * ambientLightIntensity * material.ambient * (1.0 + fresnel * 0.3);


    
    vec3 result = ambientGlobal;
    for (int i = 0; i < numLights; i++) {
        if (!lights[i].enabled) continue;
        result += calculateLight(lights[i], norm, fragPos, viewDir, material.diffuse, material.specular);
    }
    
    vec4 texColor = texture(texture1, TexCoord);
    FragColor = vec4(result, 1.0) * texColor;
}