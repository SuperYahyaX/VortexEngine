#version 330 core
out vec4 FragColor;
in vec2 TexCoords;

uniform sampler2D screenTexture;
uniform float motionBlurStrength; // 0.0 - 1.0
uniform vec2 screenSize;

// local contrast estimator
float contrast(vec3 c1, vec3 c2)
{
    return length(c1 - c2);
}

void main()
{
    vec2 texel = 1.0 / screenSize;
    vec3 base = texture(screenTexture, TexCoords).rgb;

    // Estimate "motion" direction by strongest contrast
    vec3 cRight = texture(screenTexture, TexCoords + vec2(texel.x, 0.0)).rgb;
    vec3 cLeft  = texture(screenTexture, TexCoords - vec2(texel.x, 0.0)).rgb;
    vec3 cUp    = texture(screenTexture, TexCoords + vec2(0.0, texel.y)).rgb;
    vec3 cDown  = texture(screenTexture, TexCoords - vec2(0.0, texel.y)).rgb;

    // Compute edge direction based on local differences
    vec2 dir;
    dir.x = contrast(base, cLeft) - contrast(base, cRight);
    dir.y = contrast(base, cUp)   - contrast(base, cDown);
    dir *= 60.0 * motionBlurStrength; // Amplify for visible blur

    // Normalize to avoid over-blur
    float lenDir = clamp(length(dir), 0.0, 1.0);
    dir = normalize(dir + 1e-6) * lenDir * 0.5;

    // Sample multiple points along the edge direction
    const int samples = 10;
    vec3 col = vec3(0.0);
    float total = 0.0;

    for (int i = 0; i < samples; ++i)
    {
        float t = (float(i) / float(samples - 1)) - 0.5;
        vec2 offset = dir * t;
        col += texture(screenTexture, TexCoords + offset * texel).rgb;
        total += 1.0;
    }

    col /= total;

    // Blend with base color to retain stability
    vec3 finalColor = mix(base, col, motionBlurStrength);

    FragColor = vec4(finalColor, 1.0);
}
