
#version 330 core
in vec2 TexCoord;
out vec4 FragColor;

uniform sampler2D tex;
uniform float alpha;  // new uniform for overall transparency (0.0–1.0)

void main()
{
    vec4 texColor = texture(tex, TexCoord);
    FragColor = vec4(texColor.rgb, texColor.a * alpha);
}

