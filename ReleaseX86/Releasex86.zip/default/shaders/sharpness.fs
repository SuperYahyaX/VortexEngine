#version 330 core
out vec4 FragColor;

in vec2 TexCoords;

uniform sampler2D screenTexture;
uniform float sharpnessIntensity;

void main()
{
    vec2 texelSize = 1.0 / textureSize(screenTexture, 0);
    
    // Current pixel
    vec3 center = texture(screenTexture, TexCoords).rgb;
    
    if (sharpnessIntensity > 0.0) {
        // Sample only 4 neighbors (much faster than 8)
        vec3 left = texture(screenTexture, TexCoords + vec2(-texelSize.x, 0.0)).rgb;
        vec3 right = texture(screenTexture, TexCoords + vec2( texelSize.x, 0.0)).rgb;
        vec3 top = texture(screenTexture, TexCoords + vec2(0.0, -texelSize.y)).rgb;
        vec3 bottom = texture(screenTexture, TexCoords + vec2(0.0,  texelSize.y)).rgb;
        
        // Simple sharpening: center * 2 - average of neighbors
        vec3 average = (left + right + top + bottom) * 0.25;
        vec3 sharpened = center + (center - average) * sharpnessIntensity;
        
        FragColor = vec4(sharpened, 1.0);
    } else {
        FragColor = vec4(center, 1.0);
    }
}